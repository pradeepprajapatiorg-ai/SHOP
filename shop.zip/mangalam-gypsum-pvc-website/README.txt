Mangalam Gypsum & PVC Website
================================
Open index.html in a browser to preview the website.

Included:
- Responsive black & gold shop design
- Product cards and your supplied price ranges
- Add to Cart and quantity controls
- WhatsApp ordering using 78421 59897
- Phone and WhatsApp contact
- Hyderabad address
- UPI + Cash payment information
- Cart saved in the browser

Important:
The supplied prices are ranges, so the site asks customers to confirm the final price on WhatsApp.
